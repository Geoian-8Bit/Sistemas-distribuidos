from concurrent import futures
import time
import datetime
import sys
import redis
import multiprocessing
import pika
from meteo_utils import MeteoDataProcessor

inst = MeteoDataProcessor()
r = redis.Redis(host='localhost', port=6379, db=0)

exists = r.exists("Pollution")
if (exists):
    r.delete('Pollution')
    
exists = r.exists("Air_quality")
if (exists):
    r.delete('Air_quality')

class pollution:
    def __init__(self, co2):
        self.co2 = co2

class wellness:
    def __init__(self, temperature, humidity):
        self.temperature = temperature
        self.humidity = humidity

def callback(ch, method, properties, body):

    message = body.decode()
    list_split = list(message.split(','))
    if list_split[0] == "1":
        rawPollutionData = pollution(float(list_split[1]))
        coefficient = MeteoDataProcessor.process_pollution_data(inst, rawPollutionData)
        r.hset('Pollution', list_split[2], coefficient)

        print("Pollution" + str(coefficient))
    else:
        rawAirData = wellness(float(list_split[1]),float(list_split[2]))
        coefficient = MeteoDataProcessor.process_meteo_data(inst, rawAirData)
        r.hset('Air_quality', list_split[3], coefficient)

        print("Air_quality" + str(coefficient))

    time.sleep(body.count(b'.'))
    ch.basic_ack(delivery_tag=method.delivery_tag)

def start_consumer():
    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='task_queue', durable=False)
    print(' [*] Waiting for messages. To exit press CTRL+C')

    channel.basic_qos(prefetch_count=1)
    channel.basic_consume(queue='task_queue', on_message_callback=callback)

    channel.start_consuming()

if __name__ == '__main__':
    if len(sys.argv) == 2:
        num_consumers = int(sys.argv[1])
        processes = []
        for i in range(num_consumers):
            p = multiprocessing.Process(target=start_consumer)
            p.start()
            processes.append(p)

        for p in processes:
            p.join()
    else:
     print('1 argument is required.')
     print('Introduce the number of terminals')
    

