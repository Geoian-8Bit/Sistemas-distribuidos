from concurrent import futures
import time
import datetime
import sys
import redis
import google.protobuf.timestamp_pb2 as timestamp_pb2
import pika
import statistics
import time

r = redis.Redis(host='localhost', port=6379, db=0)

connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='localhost'))
channel = connection.channel()

channel.exchange_declare(exchange='logs', exchange_type='fanout', durable=False)

if len(sys.argv) == 2:
    
    first = True
    min_time = 99999999999
    while True:
        pollution_data = []
        wellness_data = []
        
        exists = r.exists("Pollution")
       
        if (exists):
            if(first):
                first = False
                for timestamp, valor in r.hscan_iter("Pollution"): 
                     
                     if int(timestamp.decode()) < int(min_time):
                         min_time = int(timestamp)
                exists = r.exists("Air_quality")
                if (exists):
                    for timestamp, valor in r.hscan_iter("Air_quality"): 
                         if int(timestamp.decode()) < int(min_time):
                             min_time = int(timestamp)
                   
                 
            interval = min_time + int(sys.argv[1])

            print(min_time)
            print(interval)

            coefficient = r.hget("Pollution", interval+1)
            coefficient2 = r.hget("Pollution", interval+2)
            if(coefficient is not None or coefficient2 is not None):
                for i in range(min_time, interval+2): 
                    coefficient = r.hget("Pollution", i)
                    if coefficient is not None:
                         coefficient = coefficient.decode()
                         pollution_data.append(float(coefficient))

                for i in range(min_time, interval+2): 
                    coefficient = r.hget("Air_quality", i)
                    if coefficient is not None:
                         coefficient = coefficient.decode()
                         wellness_data.append(float(coefficient))

                min_time = interval

                print(pollution_data)
                print (wellness_data)

                if pollution_data:
                    pollution_mean = statistics.mean(pollution_data) 
                    print("Pollution mean: "+str(pollution_mean))
                    
                    message = '1,'+ str(pollution_mean)
                    channel.basic_publish(exchange='logs', routing_key='', body=message)
                    print(" [x] Sent %r" % message)
    
                if wellness_data:
                    wellness_mean = statistics.mean(wellness_data) 
                    print("Air quality mean: "+str(wellness_mean))

                    message = '2,'+ str(wellness_mean)
                    channel.basic_publish(exchange='logs', routing_key='', body=message)
                    print(" [x] Sent %r" % message)

        time.sleep(1)

else:
     print('1 argument is required.')
     print('Introduce the interval')

     


    