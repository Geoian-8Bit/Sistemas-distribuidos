import datetime
import time
import pika

import google.protobuf.timestamp_pb2 as timestamp_pb2
from meteo_utils import MeteoDataDetector

self = MeteoDataDetector()

while True:
    dic = MeteoDataDetector.analyze_air(self)
    print(dic['temperature'])
    print(dic['humidity'])
    timestamp = timestamp_pb2.Timestamp()
    timestamp.FromDatetime(datetime.datetime.now())

    connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='task_queue', durable=False)

    message = '2,' + str(dic['temperature']) + "," + str(dic['humidity']) + "," + str(timestamp.seconds)
    channel.basic_publish(
    exchange='',
    routing_key='task_queue',
    body=message,
    properties=pika.BasicProperties(
        delivery_mode=pika.spec.PERSISTENT_DELIVERY_MODE
    ))
    print(" [x] Sent %r" % message)

    time.sleep(1)

    

