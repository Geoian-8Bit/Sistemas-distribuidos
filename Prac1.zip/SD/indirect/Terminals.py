from concurrent import futures
import time
import datetime
import sys
import pika
import matplotlib.pyplot as plt

timesW = 5
timesP = 5
timeW = [0]
timeP = [0]
pollution_data = [0]
wellness_data = [0]



def callback(ch, method, properties, body):
    global timeP, timesP, pollution_data, timeW, timesW, wellness_data

    message = body.decode()
    list_split = list(message.split(','))
    if list_split[0] == "1":
        pollution_data.insert(0, float(list_split[1]))
        timeP.insert(0, timesP)
        timesP = timesP + int(sys.argv[1])

    else:
        wellness_data.insert(0, float(list_split[1]))
        timeW.insert(0, timesW)
        timesW = timesW + int(sys.argv[1])

    ax.clear()
    
    ax.plot(timeP, pollution_data, 'b', label='Pollution')
    ax.plot(timeW, wellness_data,'r', label='Wellness')
    
    ax.legend()
    fig.canvas.draw()
    fig.canvas.flush_events()
   

plt.ion()
fig, ax = plt.subplots()
ax.set_xlabel('Time')
ax.set_ylabel('Data')
ax.set_title('Data plot')

ax.plot(timeP, pollution_data, 'b', label='Pollution')
ax.plot(timeW, wellness_data,'r', label='Wellness')
   
ax.legend()

fig.canvas.draw()
fig.canvas.flush_events()

connection = pika.BlockingConnection(
pika.ConnectionParameters(host='localhost'))
channel = connection.channel()

channel.exchange_declare(exchange='logs', exchange_type='fanout', durable=False)

result = channel.queue_declare(queue='', exclusive=True)
queue_name = result.method.queue

channel.queue_bind(exchange='logs', queue=queue_name)

print(' [*] Waiting for logs. To exit press CTRL+C')

channel.basic_consume(
    queue=queue_name, on_message_callback=callback, auto_ack=True)

channel.start_consuming()





 

