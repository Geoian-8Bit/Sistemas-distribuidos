import datetime
import time
import pika
import sys
import google.protobuf.timestamp_pb2 as timestamp_pb2
from meteo_utils import MeteoDataDetector

self = MeteoDataDetector()

while True:
    dic = MeteoDataDetector.analyze_pollution(self)
    print(dic['co2'])
    timestamp = timestamp_pb2.Timestamp()
    timestamp.FromDatetime(datetime.datetime.now())

    connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='task_queue', durable=False)

    message = '1,' + str(dic['co2']) + "," + str(timestamp.seconds)
    channel.basic_publish(
    exchange='',
    routing_key='task_queue',
    body=message,
    properties=pika.BasicProperties(
        delivery_mode=pika.spec.PERSISTENT_DELIVERY_MODE
    ))
    print(" [x] Sent %r" % message)

    time.sleep(1)
