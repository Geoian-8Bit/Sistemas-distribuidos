import grpc
from concurrent import futures
import time
import datetime
import sys
import redis
import google.protobuf.timestamp_pb2 as timestamp_pb2
import meteo_pb2
import meteo_pb2_grpc
import statistics
import time

r = redis.Redis(host='localhost', port=6379, db=0)

if len(sys.argv) == 3:
    i = 0
    server = [None]*int(sys.argv[1])
    stub = [None]*int(sys.argv[1])
    while i < int(sys.argv[1]):
        server[i] = grpc.insecure_channel('localhost:5010'+str(i))
        stub[i] = meteo_pb2_grpc.MeteoUtilsStub(server[i])
        i+=1
    
    first = True
    min_time = 99999999999
    while True:
        pollution_data = []
        wellness_data = []
        
        exists = r.exists("Pollution")
       
        if (exists):
            if(first):
                first = False
                for timestamp, valor in r.hscan_iter("Pollution"): 
                     
                     if int(timestamp.decode()) < int(min_time):
                         min_time = int(timestamp)
                exists = r.exists("Air_quality")
                if (exists):
                    for timestamp, valor in r.hscan_iter("Air_quality"): 
                         if int(timestamp.decode()) < int(min_time):
                             min_time = int(timestamp)
                 
            interval = min_time + int(sys.argv[2])

            print(min_time)
            print(interval)

            coefficient = r.hget("Pollution", interval+1)
            coefficient2 = r.hget("Pollution", interval+2)
            if(coefficient is not None or coefficient2 is not None):
                for i in range(min_time, interval+2): 
                    coefficient = r.hget("Pollution", i)
                    if coefficient is not None:
                         coefficient = coefficient.decode()
                         pollution_data.append(float(coefficient))

                for i in range(min_time, interval+2): 
                    coefficient = r.hget("Air_quality", i)
                    if coefficient is not None:
                         coefficient = coefficient.decode()
                         wellness_data.append(float(coefficient))

                min_time = interval

                if pollution_data:
                    pollution_mean = statistics.mean(pollution_data) 
                    pollution_result = meteo_pb2.PollutionData(pollution_data=pollution_mean)
                    print("Pollution mean: "+str(pollution_mean))
                    
                    for i in range(0, int(sys.argv[1])):
                        PollutionData = meteo_pb2.PollutionData(pollution_data=pollution_mean)
                        stub[i].Send_results_pollution(PollutionData)
    
                if wellness_data:
                    wellness_mean = statistics.mean(wellness_data) 
                    wellness_result = meteo_pb2.WellnessData(wellness_data=wellness_mean)
                    print("Air quality mean: "+str(wellness_mean))
                    for i in range(0, int(sys.argv[1])):
                        WellnessData = meteo_pb2.WellnessData(wellness_data=wellness_mean)
                        stub[i].Send_results_wellness(WellnessData)

        time.sleep(1)

else:
     print('2 arguments are required.')
     print('Introduce the number of terminals and interval')

     


    