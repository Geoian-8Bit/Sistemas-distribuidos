import grpc
from concurrent import futures
import time
import datetime
import sys
import redis
import meteo_pb2
import meteo_pb2_grpc
from meteo_utils import MeteoDataProcessor

channel = grpc.insecure_channel('localhost:50100')

# create a stub (client)
stub = meteo_pb2_grpc.MeteoUtilsStub(channel)

inst = MeteoDataProcessor()

r = redis.Redis(host='localhost', port=6379, db=0)

exists = r.exists("Pollution")
if (exists):
    r.delete('Pollution')
    
exists = r.exists("Air_quality")
if (exists):
    r.delete('Air_quality')

# create a class to define the server functions, derived from
# meteo_pb2_grpc.MeteoUtilsServicer
class MeteoUtilsServicer(meteo_pb2_grpc.MeteoUtilsServicer):

    def Process_meteo_data(self, RawMeteoData, context):
        coefficient = MeteoDataProcessor.process_meteo_data(inst, RawMeteoData)
        dt = datetime.datetime.fromtimestamp(RawMeteoData.timestamp.seconds)
        r.hset('Air_quality', RawMeteoData.timestamp.seconds, coefficient)

        print(coefficient)
        print(RawMeteoData.timestamp.seconds)
        response = meteo_pb2.google_dot_protobuf_dot_empty__pb2.Empty()

        return response

    def Process_pollution_data(self, RawPollutionData, context):
        coefficient = MeteoDataProcessor.process_pollution_data(inst, RawPollutionData)
        dt3 = datetime.datetime.fromtimestamp(RawPollutionData.timestamp.seconds)
        r.hset('Pollution', RawPollutionData.timestamp.seconds, coefficient)

        print(coefficient)
        print(RawPollutionData.timestamp.seconds)
        response = meteo_pb2.google_dot_protobuf_dot_empty__pb2.Empty()

        return response


if len(sys.argv) == 2:
    i = 0
    num_port = 50052
    server = [None]*int(sys.argv[1])
    while i < int(sys.argv[1]):
        
        # create a gRPC server
        server[i] = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
        # use the generated function `add_InsultingServiceServicer_to_server`
        # to add the defined class to the server
        meteo_pb2_grpc.add_MeteoUtilsServicer_to_server(
        MeteoUtilsServicer(), server[i])
        
        print('Starting server. Listening on port '+str(num_port))
        server[i].add_insecure_port('0.0.0.0:'+str(num_port))
        server[i].start()
        num_port+=1
        i+=1
        

    i = 0
    while i < int(sys.argv[1]):
        server[i].wait_for_termination()
else:
     print('1 argument is required.')
     print('Introduce the number of servers')