import grpc
from concurrent import futures
import time
import datetime
import sys

# import the generated classes
import meteo_pb2
import meteo_pb2_grpc
import matplotlib.pyplot as plt

timesW = 5
timesP = 5
timeW = [0]
timeP = [0]
pollution_data = [0]
wellness_data = [0]

class MeteoUtilsServicer(meteo_pb2_grpc.MeteoUtilsServicer):

    def Send_results_pollution(self, PollutionData, context):
        global timeP, timesP, pollution_data
        print(PollutionData.pollution_data)
        pollution_data.insert(0, PollutionData.pollution_data)
        timeP.insert(0, timesP)
        timesP = timesP + int(sys.argv[2])
       
        response = meteo_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        return response

    def Send_results_wellness(self, WellnessData, context):
        global timeW, timesW, wellness_data
        wellness_data.insert(0, WellnessData.wellness_data)
        timeW.insert(0, timesW)
        timesW = timesW + int(sys.argv[2])
       
        response = meteo_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        return response


if len(sys.argv) == 3:

    # create a gRPC server
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))

    # use the generated function `add_InsultingServiceServicer_to_server`
    # to add the defined class to the server
    meteo_pb2_grpc.add_MeteoUtilsServicer_to_server(
        MeteoUtilsServicer(), server)

    # listen on port 50051
    print('Starting server. Listening on port 5010'+str(int(sys.argv[1])))
    server.add_insecure_port('0.0.0.0:5010'+str(int(sys.argv[1])))
    server.start()

    plt.ion()
    fig, ax = plt.subplots()
    ax.set_xlabel('Time')
    ax.set_ylabel('Data')
    ax.set_title('Data plot')

    ax.plot(timeP, pollution_data, 'b', label='Pollution')
    ax.plot(timeW, wellness_data,'r', label='Wellness')
    ax.legend()

    while True:
        ax.clear()

        ax.plot(timeP, pollution_data, 'b', label='Pollution')
        ax.plot(timeW, wellness_data,'r', label='Wellness')

        fig.canvas.draw()
        fig.canvas.flush_events()
    
        plt.pause(0.1)

else:
     print('2 arguments are required.')
     print('Introduce the number of terminal and interval')
