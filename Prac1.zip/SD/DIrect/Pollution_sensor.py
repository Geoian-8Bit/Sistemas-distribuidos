import grpc
import datetime
import time

# import the generated classes
import meteo_pb2
import meteo_pb2_grpc
import google.protobuf.timestamp_pb2 as timestamp_pb2
from meteo_utils import MeteoDataDetector
# open a gRPC channel
channel = grpc.insecure_channel('localhost:50051')

# create a stub (client)
stub = meteo_pb2_grpc.MeteoUtilsStub(channel)
self = MeteoDataDetector()


while True:
    dic = MeteoDataDetector.analyze_pollution(self)
    timestamp = timestamp_pb2.Timestamp()
    timestamp.FromDatetime(datetime.datetime.now())
    RawPollutionData = meteo_pb2.RawPollutionData(co2=dic['co2'], timestamp=timestamp)
    stub.Send_pollution_data(RawPollutionData)
    time.sleep(1)
