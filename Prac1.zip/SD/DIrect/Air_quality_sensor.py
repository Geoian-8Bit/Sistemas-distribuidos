import grpc
import datetime
import time

# import the generated classes
import meteo_pb2
import meteo_pb2_grpc
import google.protobuf.timestamp_pb2 as timestamp_pb2
from meteo_utils import MeteoDataDetector
# open a gRPC channel
channel = grpc.insecure_channel('localhost:50051')

# create a stub (client)
stub = meteo_pb2_grpc.MeteoUtilsStub(channel)
self = MeteoDataDetector()

while True:
    dic = MeteoDataDetector.analyze_air(self)
    timestamp = timestamp_pb2.Timestamp()
    timestamp.FromDatetime(datetime.datetime.now())
    RawMeteoData = meteo_pb2.RawMeteoData(temperature=dic['temperature'], humidity=dic['humidity'], timestamp=timestamp)
    stub.Send_meteo_data(RawMeteoData)
    time.sleep(1)

    

