import grpc
from concurrent import futures
import time
import datetime
import sys
import meteo_pb2
import meteo_pb2_grpc


index = 0

# create a class to define the server functions, derived from
# meteo_pb2_grpc.MeteoUtilsServicer
class MeteoUtilsServicer(meteo_pb2_grpc.MeteoUtilsServicer):
    

    def Send_meteo_data(self, RawMeteoData, context):
        global index
            
        dt = datetime.datetime.fromtimestamp(RawMeteoData.timestamp.seconds)
        RawMeteoData = meteo_pb2.RawMeteoData(temperature=RawMeteoData.temperature, humidity=RawMeteoData.humidity, timestamp=RawMeteoData.timestamp)
        stub[index].Process_meteo_data.future(RawMeteoData)

        print(index)
        index+=1 
        index = index % int(sys.argv[1])
        
        response = meteo_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        return response

    def Send_pollution_data(self, RawPollutionData, context):
        global index

        dt3 = datetime.datetime.fromtimestamp(RawPollutionData.timestamp.seconds)
        RawPollutionData = meteo_pb2.RawPollutionData(co2=RawPollutionData.co2, timestamp=RawPollutionData.timestamp)
        stub[index].Process_pollution_data.future(RawPollutionData)

        print(index)
        index+=1
        index = index % int(sys.argv[1])

        response = meteo_pb2.google_dot_protobuf_dot_empty__pb2.Empty()
        return response

if len(sys.argv) == 2:

    i = 0
    num_port = 50052
    server = [None]*int(sys.argv[1])
    stub = [None]*int(sys.argv[1])
    while i < int(sys.argv[1]):
        
        server[i] = grpc.insecure_channel('localhost:'+str(num_port))
        stub[i] = meteo_pb2_grpc.MeteoUtilsStub(server[i])
        num_port+=1
        i+=1

    # create a gRPC server
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))

    # use the generated function `add_InsultingServiceServicer_to_server`
    # to add the defined class to the server
    meteo_pb2_grpc.add_MeteoUtilsServicer_to_server(
        MeteoUtilsServicer(), server)

    # listen on port 50051
    print('Starting server. Listening on port 50051.')
    server.add_insecure_port('0.0.0.0:50051')
    server.start()

    # since server.start() will not block,
    # a sleep-loop is added to keep alive
    try:
        while True:
            time.sleep(86400)
    except KeyboardInterrupt:
        server.stop(0)
else:
     print('1 argument is required.')
     print('Introduce the number of servers')